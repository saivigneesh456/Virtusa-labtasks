package labtasks;

import java.io.*;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.logging.*;

public class ExcelProblem9 {
	static BufferedReader br;
	static Log log;
	public static List<Student5th> studentsList = new LinkedList<Student5th>();

	private synchronized static void readCsv() throws SecurityException, IOException {
		String line = "";
		try {
			while ((line = br.readLine()) != null) {
				String[] student = line.split(";");
				Student5th ob = new Student5th(student[0], student[1], student[2], Integer.parseInt(student[3]));
				studentsList.add(ob);
			}
		} catch (Exception e) {
			log.info("Info msg");
			log.warn("Warning msg");
			log.error(e);
		}
	}

	private synchronized static void getGradesOFStudents() {
		File file = new File("D:\\JAva\\code\\virtusa\\src\\labtasks\\excelProblemResult.csv");
		String result = "NA";
		String seperator = ";";
		try {
			FileWriter fileWrite = new FileWriter(file);
			BufferedWriter writer = new BufferedWriter(fileWrite);
			for (Student5th student5th : studentsList) {
				if (student5th.getMarks() >= 75) {
					result = "Distinction";
				} else if (student5th.getMarks() >= 40 && student5th.getMarks() < 75) {
					result = "Passed";
				} else {
					result = "Not Cleared";
				}
				writer.write(student5th.getFirstName() + seperator + student5th.getDepartment() + seperator
						+ student5th.getSubject() + seperator + student5th.getMarks() + seperator + result);
				writer.newLine();
			}
			writer.close();
			fileWrite.close();
		} catch (Exception e) {
			log.info("Info msg");
			log.warn("Warning msg");
			log.error(e);
		}
	}

	public static void main(String[] args) throws SecurityException, IOException {
		Thread t1 = new Thread(new Runnable() {			
			@Override
			public void run() {
				try {
					readCsv();
					getGradesOFStudents();		
				} catch (IOException e) {
					log.error(e);
					throw new RuntimeException(e);
				}
					
			}
		});
		
		try {
			br = new BufferedReader(new FileReader("D:\\JAva\\code\\virtusa\\src\\labtasks\\excelProblem.csv"));

		} catch (Exception e) {
			log.info("Info msg");
			log.warn("Warning msg");
			log.error(e);
		}
		t1.start();
		for (Student5th student5th : studentsList) {
			log.info(student5th.getFirstName() + " " + student5th.getMarks());
		}

	}
}
