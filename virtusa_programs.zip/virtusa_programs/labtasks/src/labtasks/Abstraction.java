package labtasks;

public class Abstraction {
	private int length;
	private int breadth;

	public Abstraction() {
		length = 0;
		breadth = 0;
	}

	public Abstraction(int x, int y) {
		length = x;
		breadth = y;
	}

	public void setval(int x, int y) {
		length = x;
		breadth = y;
	}

	public int area() {
		return (length * breadth);
	}
}

