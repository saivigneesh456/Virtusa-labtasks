package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import labtasks.Polymorphism;

public class PolymorphismTest {

	Polymorphism po = new Polymorphism(25,8); 
	@Test
	public void isNegativeTest() {
		assertEquals( po.isPositive(), true);
		assertEquals( po.isZero(),false);
		assertEquals(po.isNegative(),false);
		assertEquals(po.isodd(),true);
		assertEquals(po.isEven(),false);
		assertEquals(po.isPrime(),true);

	}
}
