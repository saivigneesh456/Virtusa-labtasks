package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import labtasks.Abstraction;
import labtasks.Box3d;

class BoxTest {

	@Test
	void testarea() {

		Abstraction obj = new Abstraction(1, 4);
		assertEquals(obj.area(), 4);
	}
	@Test
	public void testVolume() {
		Box3d b2 = new Box3d(12, 34, 18);
        assertEquals(b2.volume(), 7344);
    }
	
	

}